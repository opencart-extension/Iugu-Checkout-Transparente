<?php

class Iugu_PaymentToken extends APIResource {
  public static function create($attributes=Array()) { return self::createAPI($attributes); }
}
