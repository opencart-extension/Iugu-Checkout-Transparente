<?php
$_['text_iugu_view_invoice'] 	= 'Ver Fatura';
$_['text_iugu_send_invoice'] 	= 'Reemitir Fatura';
$_['text_iugu_refund'] 			= 'Reembolsar';
$_['text_iugu_cancel'] 			= 'Cancelar Fatura';
$_['text_iugu_invoice_sent'] 	= 'Fatura enviada';
$_['text_invoice_refunded'] 	= 'Fatura reembolsada com sucesso';
$_['text_invoice_canceled'] 	= 'Fatura cancelada com sucesso';
$_['text_mail_subject']			= '%s - Download';
$_['text_mail_html']			= 'Segue anexo o arquivo solicitado.';
$_['text_mail_text']			= 'Segue anexo o arquivo solicitado.';