<?php
//Heading
$_['heading_title'] 						= 'Iugu - Cartão de Crédito';

//Text
$_['text_iugu_billet'] 						= '<img src="https://d21fvzaqybvyws.cloudfront.net/9CA0F40E971643D1B7C8DE46BBC18396/images/30/30/52a4f0158b66582bc0df886178544375246dd3577d997.jpg" alt="' . $_['heading_title'] . '" title="' . $_['heading_title'] . '" style="border: 1px solid #EEEEEE;" height="31" />';